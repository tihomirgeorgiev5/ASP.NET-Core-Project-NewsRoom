﻿namespace NewsRoom.Services.Statistics
{
    public interface IStatisticsService
    {
        StatisticsServiceModel Total();
    }
}
