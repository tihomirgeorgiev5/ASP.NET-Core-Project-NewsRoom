﻿namespace NewsRoom.Models
{
    public enum NewsSorting
    {
        DateCreated = 0,
        Date = 1,
        AreaAndTitle = 2
    }
}
