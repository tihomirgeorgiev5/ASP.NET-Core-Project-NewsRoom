﻿namespace NewsRoom.Data
{
    public class DataConstants
    {
        public const int NewsAreaMaxLength = 30;

        public const int NewsTitleMaxLength = 50; 
        public const int NewsDescriptionMaxLength = 10000; 
    }
}
