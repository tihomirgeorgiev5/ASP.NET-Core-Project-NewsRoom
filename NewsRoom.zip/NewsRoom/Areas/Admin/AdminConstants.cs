﻿namespace NewsRoom.Areas.Admin
{
    public class AdminConstants
    {
        public const string AreaName = "Admin";
        public const string AdministratorRoleName = "Administrator";
    }
}
