﻿namespace NewsRoom.Services.News.Models
{
    public class NewsCategoryServiceModel
    {
        public int Id { get; init; }

        public string Name { get; init; }
    }
}
 