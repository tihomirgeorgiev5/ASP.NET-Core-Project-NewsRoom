﻿namespace NewsRoom
{
    public class WebConstants
    {
        public const string GlobalMessageKey = "GlobalMessage";

        public class Cache
        {
            public const string LatestNewsCacheKey = nameof(LatestNewsCacheKey); 
        }
    }
}
